#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
//#include <stdint.h>
#include <vector>
#include <fstream>
#include <stack>
#include <regex>
#include <map>
//#include <cmath>
//#include <cstring>
//#include <functional>
//#include <limits>

//#include <fcntl.h>
//#include <errno.h>
//#include <sys/types.h>
//#include <unistd.h>

//Wad Class
//The Wad class is used to represent WAD data and should have the following functions. The root of all paths in the WAD data should be "/", and each directory should be separated by '/' (e.g., "/F/F1/LOLWUT").

struct LumpDescriptor{
//private:

public:
	uint32_t offset;
	uint32_t length;
	std::string name;
	bool isDirectory;

};

class Wad{
private:
	std::ifstream fstr;
	std::string path;
	char* magic;
	uint32_t numDescriptors;
	uint32_t descriptorOffset;
	std::vector<LumpDescriptor> descriptors;
	std::map<std::string, LumpDescriptor> mappy;

public:
	Wad();
	~Wad();

	static Wad* loadWad(const std::string &path);
	char* getMagic();
	bool isContent(const std::string &path);
	bool isDirectory(const std::string &path);
	int getSize(const std::string &path);
	int getContents(const std::string &path, char *buffer, int length, int offset);
	int getDirectory(const std::string &path, std::vector<std::string> *directory);

};