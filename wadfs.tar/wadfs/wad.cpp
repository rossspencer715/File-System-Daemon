#include "wad.h"

//Wad Class
//The Wad class is used to represent WAD data and should have the following functions. The root of all paths in the WAD data should be "/", and each directory should be separated by '/' (e.g., "/F/F1/LOLWUT").

Wad::Wad(){
	this->path = "";
}


Wad::~Wad(){
	delete [] this->magic;
}

//using workingDirectory vector as a stack
std::string stackToPath(std::vector<std::string> stacky){
	if(stacky.size() <= 0){
		return "/";
	}

	std::string str = "";
	for(int i = 0; i < stacky.size(); i++){
		str = str + "/" + stacky[i];
	}	

	//str += "/";

	return str;
}

//Object allocator; creates a Wad object and loads the WAD file data from path into memory.
Wad* Wad::loadWad(const std::string &path){
	/*if(path.at(0) != '/'){
		std::cout << "ERROR: invalid path! Does not start with \'/\'\n\n";
	}*/
	static Wad* file = new Wad();
	file->path = path;
	std::string pathname = path;//"/Users/rossspencer/Downloads/Project3/DOOM1.WAD";
	
	file->fstr.open(pathname, std::ios::binary);

	if(!file->fstr.is_open()){
		std::cout << "Error: file DNE\n\n\n";
		return nullptr;
	}
	//fstr.open("DOOM1.WAD", std::ios::binary);

	file->magic = new char[5];
	char* ready = new char[4];

	//file->numDescriptors = new char[4];
	//file->descriptorOffset = new char[4];

	file->fstr.read(file->magic, 4);
	file->magic[4] = '\0';
	file->fstr.read(ready, 4);
	file->numDescriptors = *(uint32_t*)ready;
	file->fstr.read(ready, 4);
	file->descriptorOffset = *(uint32_t*)ready;
	//fstr.read(file->, 4);
	delete [] ready;

	int times = (file->numDescriptors);

	file->fstr.seekg(file->descriptorOffset, std::ios::beg);

	LumpDescriptor des;
	for(int i = 0; i < times; i++){
		char* ready = new char[4];
		file->fstr.read(ready, 4*sizeof(char));
		des.offset = *(uint32_t*)ready;
		//des.length = new char[4];
		file->fstr.read(ready, 4*sizeof(char));
		des.length = *(uint32_t*)ready;
		delete [] ready;

		ready = new char[9];
		file->fstr.read(ready, 8*sizeof(char));
		ready[8] = '\0';
		std::string bingowashisnameoh(ready);
		des.name = bingowashisnameoh;

		file->descriptors.push_back(des);
		delete [] ready;
	}

	bool inMap = false;
	std::string str;
	std::regex testy("E[0-9]M[0-9]");
	std::regex starty("\\w+_START");
	std::regex endy("\\w+_END");
	for(int i = 0; i < times; i++){
		des = file->descriptors[i];
		std::string str = des.name;
		
		if(std::regex_match(str, testy)){
			file->descriptors[i].isDirectory = true;
		}
		else if(std::regex_match(str, starty)){
			file->descriptors[i].isDirectory = true;
		}
		else if(std::regex_match(str, endy)){
			file->descriptors[i].isDirectory = true;
		}
		else{
			file->descriptors[i].isDirectory = false;
		}
		
	}


	//fstr.read(reinterpret_cast<char*>(&myint), sizeof(int));
	//std::cout << " my int is " << myint << std::endl;
	//fstr.read(reinterpret_cast<char*>(&myint), sizeof(int));
	//std::cout << " my int is " << myint << std::endl;
	//fstr.read(reinterpret_cast<char*>(&arr), 8*sizeof(char));
	//std::cout << " my name is " << arr << std::endl;
/*
	std::cout << file->magic << " is magic\n";
	std::cout << file->numDescriptors << " is numDescriptors\n";
	std::cout << file->descriptorOffset << " is descriptorOffset\n\n\n";
	for(auto& des : file->descriptors){
		std::cout << des.offset << " is offset\n";
		std::cout << des.length << " is length\n";
		std::cout << des.name << " is name\n";
		std::cout << des.isDirectory << " is isDirectory\n\n";
	}
*/




	std::regex start("\\w+_START");
	std::regex end("\\w+_END");
	std::regex EWhatMWhat("E[0-9]M[0-9]");
	std::map<std::string, LumpDescriptor>* mappyPtr = &file->mappy;

	//idea: hash map with path as key and descriptor as value
	//stack to track workingDirectory
	std::vector<std::string> workingDirectory;
	std::string dir;
	for(int i = 0; i < file->descriptors.size(); i++){
		dir = "";
		dir = stackToPath(workingDirectory);
		if (dir.back() != '/'){
			dir += "/";
		} 
		//start of a directory
		if(std::regex_match(file->descriptors[i].name, start)){
			std::string strang = file->descriptors[i].name;
			workingDirectory.push_back(strang.substr(0, strang.size()-6));
			dir += strang.substr(0, strang.size()-6);
			//if(dir.back() == '/'){
			//	dir = dir.substr(0, dir.size()-1);
			//}
			mappyPtr->insert(std::pair<std::string,LumpDescriptor>(dir, file->descriptors[i]));
		}
		//start of a map
		else if(std::regex_match(file->descriptors[i].name, EWhatMWhat)){
			dir += file->descriptors[i].name;
			//if(dir.back() == '/'){
			//	dir = dir.substr(0, dir.size()-1);
			//}
			mappyPtr->insert(std::pair<std::string,LumpDescriptor>(dir, file->descriptors[i]));
			//workingDirectory.push_back(file->descriptors[i].name);
			for(int j = i + 1; j <= i + 10; j++){
				dir = "";
				dir = stackToPath(workingDirectory);
				if (dir.back() != '/'){
					dir += "/";
				} 
				dir = dir + file->descriptors[i].name + "/" + file->descriptors[j].name;
				//if(dir.back() == '/'){
				//	dir = dir.substr(0, dir.size()-1);
				//}
				mappyPtr->insert(std::pair<std::string,LumpDescriptor>(dir, file->descriptors[j]));
			}
			i += 10;
		}
		//end of a directory
		else if(std::regex_match(file->descriptors[i].name, end)){
			workingDirectory.pop_back();
			continue;
		}
		//just content
		else{
			dir += file->descriptors[i].name;
			//if(dir.back() == '/'){
			//	dir = dir.substr(0, dir.size()-1);
			//}
			mappyPtr->insert(std::pair<std::string,LumpDescriptor>(dir, file->descriptors[i]));
		}
		//std::cout << " idk what im doing but " << dir << " is dir lulkek\n\n";
	}

	/*
	std::map<std::string, LumpDescriptor>::iterator it;
	itty = mappyPtr->begin();
	itty = mappyPtr->find("/F/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/F1/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/F/F1");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/F/F1/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/F1/F/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/E1M1/THINGS/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/E1M1/THINGS/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/PLAYPAL/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/ENDOOM/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}
	itty = mappyPtr->find("/F/ENDOOM/");
	if(it != mappyPtr->end())
		std::cout << itty->first << "\n\n\n\n\n\n";
	else{
		std::cout << "oops\n\n\n\n\n\n";
	}*/

	if(file){
		return file;
	}

	return nullptr;
}

//Returns the magic for this WAD data.
char* Wad::getMagic(){
	return this->magic;
}

//Returns true if path represents content (data), and false otherwise.
bool Wad::isContent(const std::string &path){
	std::map<std::string, LumpDescriptor>::iterator itty;
	itty = this->mappy.begin();
	itty = this->mappy.find(path);
	//path is invalid
	/*if(itty == this->mappy.end()){
		std::string pathy = path;
		pathy.pop_back();
		itty = this->mappy.find(pathy);
	}*/
	if(itty == this->mappy.end()){
		return false;
	}

	//check that it's not a directory
	if(itty->second.isDirectory){
		return false;
	}	

	//woot it's content
	else{
		return true;
	}
}


//Returns true if path represents a directory, and false otherwise.
bool Wad::isDirectory(const std::string &path){
	if(path.compare("/") == 0){
		return true;
	}
	std::map<std::string, LumpDescriptor>::iterator itty;
	itty = this->mappy.begin();
	itty = this->mappy.find(path);
	
	if(itty == this->mappy.end()){
		std::string pathy = path;
		if(pathy.back() == '/'){
			pathy.pop_back();
		} 
		itty = this->mappy.find(pathy);
	}
	//path is invalid
	if(itty == this->mappy.end()){
		return false;
		
	}

	//check that it's a directory
	if(itty->second.isDirectory){
		return true;
	}	

	//eww it's content
	else{
		return false;
	}
}

//If path represents content, returns the number of bytes in its data; otherwise, returns -1.
int Wad::getSize(const std::string &path){
	if(this->isContent(path)){
		std::map<std::string, LumpDescriptor>::iterator itty;
		itty = this->mappy.begin();
		itty = this->mappy.find(path);

		if(itty == this->mappy.end()){
			std::string pathy = path;
			if(pathy.back() == '/'){
				pathy.pop_back();
			}	 
			itty = this->mappy.find(pathy);
		}
		//path is invalid
		if(itty == this->mappy.end()){
			return false;
		}

		/*if(itty == this->mappy.end()){
			return false;
		}*/
		return itty->second.length;
	}
	return -1;
}

//If path represents content, copies up to length bytes of its data into buffer. If offset is provided, data should be copied starting from that byte in the content. Returns the number of bytes copied into the buffer, or -1 if path does not represent content (e.g., if it represents a directory).
int Wad::getContents(const std::string &path, char *buffer, int length, int offset = 0){
	if(this->isContent(path)){
		int startOfContents = 0;
		std::map<std::string, LumpDescriptor>::iterator itty;
		itty = this->mappy.find(path);
		int len = 0;
		int lengthCopied = 0;
		/*if(itty == this->mappy.end()){
			std::string pathy = path;
			pathy.pop_back();
			itty = this->mappy.find(pathy);
		}*/
		//in theory this is already checked in isContent, but yolo I guess??
		if(itty != this->mappy.end()){
			startOfContents = itty->second.offset;
			len = itty->second.length;
		}
		if(length > len - offset){
			lengthCopied = len - offset;
		}
		else{
			lengthCopied = length;
		}
		/*if(buffer != nullptr){
			delete [] buffer;
		}
		buffer = new char[length]; */
		fstr.seekg(startOfContents + offset, std::ios::beg);
		fstr.read(buffer, lengthCopied);
		return lengthCopied;
	}

	return -1;
}

//If path represents a directory, places entries for contained elements in directory. Returns the number of elements in the directory, or -1 if path does not represent a directory (e.g., if it represents content).
int Wad::getDirectory(const std::string &path, std::vector<std::string> *directory){
	if(this->isDirectory(path)){
		int county = 0;
		std::map<std::string, LumpDescriptor>::iterator itty;
		itty = this->mappy.begin();
		while(itty != this->mappy.end()){
			if(itty->first.compare(path + "/" + itty->second.name) == 0 || itty->first.compare(path + itty->second.name) == 0){
				//directory->push_back(itty->first);
				directory->push_back(itty->second.name);
				county++;
			}
			else if((itty->first + "_START").compare(path + "/" + itty->second.name) == 0 || (itty->first + "_START").compare(path + itty->second.name) == 0){
				//directory->push_back(itty->first);
				directory->push_back(itty->second.name.substr(0, itty->second.name.length() - 6));
				county++;
			}
			itty++;
		}

		return county;
	}
	return -1;
}
/*
int main(){
	Wad* waddle = Wad::loadWad("/Users/rossspencer/Downloads/Project3/DOOM1.WAD");
	//test that THINGS is false since it's in E1M1 
	bool yesno = waddle->isDirectory("/");
	std::cout << "/ is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/F/F1");
	std::cout << "F/F1 is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/F/F1/");
	std::cout << "F/F1/ is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/F1/F");
	std::cout << "F1/F is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/F1/F/");
	std::cout << "/F1/F/ is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/E1M1/DPPISTOL");
	std::cout << "E1M1/DPPISTOL is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/E1M9/DPPISTOL");
	std::cout << "E1M9/DPPISTOL is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/E1M1");
	std::cout << "E1M1 is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/DPPISTOL");
	std::cout << "DPPISTOL is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/E1M1/THINGS");
	std::cout << "E1M1/THINGS is " << yesno << " a directory\n\n";
	yesno = waddle->isDirectory("/THINGS");
	std::cout << "THINGS is " << yesno << " a directory\n\n\n\n";


	yesno = waddle->isContent("/F/F1");
	std::cout << "F/F1 is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/F/F1/");
	std::cout << "F/F1/ is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/F1/F");
	std::cout << "F1/F is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/F1/F/");
	std::cout << "/F1/F/ is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/E1M1/DPPISTOL");
	std::cout << "E1M1/DPPISTOL is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/E1M9/DPPISTOL");
	std::cout << "E1M9/DPPISTOL is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/E1M1");
	std::cout << "E1M1 is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/DPPISTOL");
	std::cout << "DPPISTOL is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/E1M1/THINGS");
	std::cout << "E1M1/THINGS is " << yesno << " a content\n\n";
	yesno = waddle->isContent("/THINGS");
	std::cout << "THINGS is " << yesno << " a content\n\n";

	std::vector<std::string> lmao;
	std::cout << waddle->getDirectory("/F", &lmao) << " # elements in F\n";
	for(auto& lol : lmao){
		std::cout << lol << " lmao\n";
	}

	lmao.clear();
	std::cout << waddle->getDirectory("/F/F1", &lmao) << " # elements in F/F1\n";
	for(auto& lol : lmao){
		std::cout << lol << " lmao\n";
	}

	lmao.clear();
	std::cout << waddle->getDirectory("/F/F1/", &lmao) << " # elements in F/F1/\n";
	for(auto& lol : lmao){
		std::cout << lol << " lmao\n";
	}

	lmao.clear();
	std::cout << waddle->getDirectory("/", &lmao) << " # elements in /\n";
	for(auto& lol : lmao){
		std::cout << lol << " lmao\n";
	}

	std::vector<std::string> idk;
	idk.push_back("test");
	idk.push_back("lmao");
	std::cout << stackToPath(idk) << "\n";

	char* buffy = new char[64];
	std::cout << waddle->getContents("/F/F1/DEM1_1", buffy, 12, 3) << " and " << *(unsigned int*)buffy << " is buffy\n";
	
	return 0;
}*/
