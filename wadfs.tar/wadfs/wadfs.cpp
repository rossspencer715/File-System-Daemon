#include "fuse.h"
#include "wad.cpp"
#include <iostream>
#include <vector>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <syslog.h>
#include <string.h>

/*

I.e., instead do...
fuse_operations wad_ops;
wad_ops.getattr = ...

*/

//getattr - permissions, filetype (directory/content), and size
//read - getContents
//readdir - getDirectory
//open - return 0 if content, error if directory
//

struct fuse_operations wad_ops;
Wad* waddle;

static int read_callback(const char* path, char* buf, size_t size, off_t offset, struct fuse_file_info* fi){
    if(!waddle->isContent(path)){
        return -ENOENT;
    }
    return waddle->getContents(path, buf, size, offset);
}


static int open_callback(const char* path, struct fuse_file_info* fi){ 
    if(!waddle->isContent(path)){
        return -ENOENT;
    }
    return 0;
}


static int getattr_callback(const char* path, struct stat* st){
    st->st_uid = getuid();
    st->st_gid = getgid();
    st->st_atime = time(NULL);
    st->st_mtime = time(NULL);

    if (strcmp(path, "/") == 0 ){
        st->st_mode = S_IFDIR | 0555;
        st->st_nlink = 2;
    }
    else if(waddle->isDirectory(path)){
        st->st_mode = S_IFDIR | 0555;
        std::vector<std::string> check;
        int size = waddle->getDirectory(path,&check);
        st->st_nlink = size;
    }
    else{
        st->st_mode = S_IFREG | 0444; //0644
        st->st_nlink = 1;
        st->st_size = waddle->getSize(path);
    }
    return 0;
}

static int readdir_callback(const char* path, void* buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info* fi){
    std::vector<std::string> dir;
    int size = waddle->getDirectory(path, &dir);
    filler(buf, ".", NULL,0);
    filler(buf, "..", NULL, 0);
    for(std::string d : dir){
        filler(buf, d.c_str(), NULL, 0);
    }
    return 0;
}

static int opendir_callback(const char* path, struct fuse_file_info* fi){
    if(!waddle->isDirectory(path)){
        return -ENOENT;
    }
    return 0;
}

void set_ops(){
    wad_ops.getattr = getattr_callback;
    wad_ops.open = open_callback;
    wad_ops.read = read_callback;
    wad_ops.readdir = readdir_callback;
    wad_ops.opendir = opendir_callback;
    return;
}

int main(int argc, char* argv[]) {

    if(argc < 2){
        //std::cout << "ERROR: no file selected. Exiting.\n";
        return 1;
    }

    set_ops();

    waddle = waddle->loadWad(argv[1]);
    char* mounter[argc-1];
    mounter[0] = argv[0];
    for(int i = 1; i < argc-1; i++){
        mounter[i] = argv[i+1];
    }

    return fuse_main(argc-1, mounter, &wad_ops, NULL);


   exit(EXIT_SUCCESS);
}

